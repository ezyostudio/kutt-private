"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.remove = exports.key = exports.del = exports.set = exports.get = void 0;
const util_1 = require("util");
const redis_1 = __importDefault(require("redis"));
const env_1 = __importDefault(require("./env"));
const client = redis_1.default.createClient({
    host: env_1.default.REDIS_HOST,
    port: env_1.default.REDIS_PORT,
    ...(env_1.default.REDIS_PASSWORD && { password: env_1.default.REDIS_PASSWORD })
});
exports.get = util_1.promisify(client.get).bind(client);
exports.set = util_1.promisify(client.set).bind(client);
exports.del = util_1.promisify(client.del).bind(client);
exports.key = {
    link: (address, domain_id, user_id) => `${address}-${domain_id || ""}-${user_id || ""}`,
    domain: (address) => `d-${address}`,
    stats: (link_id) => `s-${link_id}`,
    host: (address) => `h-${address}`,
    user: (emailOrKey) => `u-${emailOrKey}`
};
exports.remove = {
    domain: (domain) => {
        if (!domain)
            return;
        exports.del(exports.key.domain(domain.address));
    },
    host: (host) => {
        if (!host)
            return;
        exports.del(exports.key.host(host.address));
    },
    link: (link) => {
        if (!link)
            return;
        exports.del(exports.key.link(link.address, link.domain_id));
    },
    user: (user) => {
        if (!user)
            return;
        exports.del(exports.key.user(user.email));
        exports.del(exports.key.user(user.apikey));
    }
};
//# sourceMappingURL=redis.js.map