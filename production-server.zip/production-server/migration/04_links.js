"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const env_1 = __importDefault(require("../env"));
const neo4j_driver_1 = require("neo4j-driver");
const date_fns_1 = require("date-fns");
const p_queue_1 = __importDefault(require("p-queue"));
const knex_1 = __importDefault(require("knex"));
let count = 0;
const queue = new p_queue_1.default({ concurrency: 5 });
queue.on("active", () => (count % 1000 === 0 ? console.log(count++) : count++));
// 1. Connect to Neo4j database
const neo4j = neo4j_driver_1.v1.driver(env_1.default.NEO4J_DB_URI, neo4j_driver_1.v1.auth.basic(env_1.default.NEO4J_DB_USERNAME, env_1.default.NEO4J_DB_PASSWORD));
// 2. Connect to Postgres database
const postgres = knex_1.default({
    client: "postgres",
    connection: {
        host: env_1.default.DB_HOST,
        database: env_1.default.DB_NAME,
        user: env_1.default.DB_USER,
        password: env_1.default.DB_PASSWORD
    }
});
(async function () {
    const startTime = Date.now();
    // 3. [NEO4J] Get all links
    const session = neo4j.session();
    const { records } = await session.run("MATCH (l:URL) WITH COUNT(l) as count RETURN count");
    const total = records[0].get("count").toNumber();
    const limit = 20000;
    function main(index = 0) {
        queue.add(() => new Promise((resolve, reject) => {
            session
                .run("MATCH (l:URL) WITH l SKIP $skip LIMIT $limit " +
                "OPTIONAL MATCH (l)-[:USES]->(d) " +
                "OPTIONAL MATCH (l)<-[:CREATED]-(u) " +
                "OPTIONAL MATCH (v)-[:VISITED]->(l) " +
                "OPTIONAL MATCH (v)-[:BROWSED_BY]->(b) " +
                "OPTIONAL MATCH (v)-[:OS]->(o) " +
                "OPTIONAL MATCH (v)-[:LOCATED_IN]->(c) " +
                "OPTIONAL MATCH (v)-[:REFERRED_BY]->(r) " +
                "OPTIONAL MATCH (v)-[:VISITED_IN]->(dd) " +
                "WITH l, u, d, COLLECT([b.browser, o.os, c.country, r.referrer, dd.date]) as stats " +
                "RETURN l, u.email as email, d.name as domain, stats", { limit: limit, skip: index * limit })
                .subscribe({
                onNext(record) {
                    queue.add(async () => {
                        const link = record.get("l").properties;
                        const email = record.get("email");
                        const address = record.get("domain");
                        const stats = record.get("stats");
                        // 4. Merge and normalize stats based on hour
                        const visits = {};
                        stats.forEach(([b, o, country, referrer, date]) => {
                            if (b && o && country && referrer && date) {
                                const dateHour = date_fns_1.startOfHour(new Date(date)).toISOString();
                                const browser = b.toLowerCase();
                                const os = o === "Mac Os X" ? "macos" : o.toLowerCase();
                                visits[dateHour] = {
                                    ...visits[dateHour],
                                    total: ((visits[dateHour] &&
                                        visits[dateHour].total) || 0) + 1,
                                    [`br_${browser}`]: ((visits[dateHour] &&
                                        visits[dateHour][`br_${browser}`]) ||
                                        0) + 1,
                                    [`os_${os}`]: ((visits[dateHour] &&
                                        visits[dateHour][`os_${os}`]) || 0) + 1,
                                    countries: {
                                        ...(visits[dateHour] || {}).countries,
                                        [country.toLowerCase()]: ((visits[dateHour] &&
                                            visits[dateHour].countries[country.toLowerCase()]) ||
                                            0) + 1
                                    },
                                    referrers: {
                                        ...(visits[dateHour] || {}).referrers,
                                        [referrer.toLowerCase()]: ((visits[dateHour] &&
                                            visits[dateHour].referrers[referrer.toLowerCase()]) ||
                                            0) + 1
                                    }
                                };
                            }
                        });
                        // 5. [Postgres] Find matching user and or domain
                        const [user, domain] = await Promise.all([
                            email &&
                                postgres("users")
                                    .where({ email })
                                    .first(),
                            address &&
                                postgres("domains")
                                    .where({ address })
                                    .first()
                        ]);
                        // 6. [Postgres] Create link
                        const data = {
                            address: link.id,
                            banned: !!link.banned,
                            domain_id: domain ? domain.id : null,
                            password: link.password,
                            target: link.target,
                            user_id: user ? user.id : null,
                            ...(link.count && { visit_count: link.count.toNumber() }),
                            ...(link.createdAt && { created_at: link.createdAt })
                        };
                        const res = await postgres("links").insert(data, "id");
                        const link_id = res[0];
                        // 7. [Postgres] Create visits
                        const newVisits = Object.entries(visits).map(([date, details]) => ({
                            link_id,
                            created_at: date,
                            countries: details.countries,
                            referrers: details.referrers,
                            total: details.total,
                            br_chrome: details.br_chrome,
                            br_edge: details.br_edge,
                            br_firefox: details.br_firefox,
                            br_ie: details.br_ie,
                            br_opera: details.br_opera,
                            br_other: details.br_other,
                            br_safari: details.br_safari,
                            os_android: details.os_android,
                            os_ios: details.os_ios,
                            os_linux: details.os_linux,
                            os_macos: details.os_macos,
                            os_other: details.os_other,
                            os_windows: details.os_windows
                        }));
                        await postgres("visits").insert(newVisits);
                    });
                },
                onCompleted() {
                    session.close();
                    if ((index + 1) * limit < total) {
                        queue.add(() => main(index + 1));
                    }
                    else {
                        queue.add(() => {
                            const endTime = Date.now();
                            console.log(`✅ Done! It took ${(endTime - startTime) /
                                1000} seconds.`);
                        });
                    }
                    resolve(null);
                },
                onError(error) {
                    session.close();
                    if ((index + 1) * limit < total) {
                        queue.add(() => main(index + 1));
                    }
                    reject(error);
                }
            });
        }));
    }
    main();
})();
//# sourceMappingURL=04_links.js.map