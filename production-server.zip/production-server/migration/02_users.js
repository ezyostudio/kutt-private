"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const env_1 = __importDefault(require("../env"));
const neo4j_driver_1 = require("neo4j-driver");
const p_queue_1 = __importDefault(require("p-queue"));
const knex_1 = __importDefault(require("knex"));
const queue = new p_queue_1.default({ concurrency: 10 });
// 1. Connect to Neo4j database
const neo4j = neo4j_driver_1.v1.driver(env_1.default.NEO4J_DB_URI, neo4j_driver_1.v1.auth.basic(env_1.default.NEO4J_DB_USERNAME, env_1.default.NEO4J_DB_PASSWORD));
// 2. Connect to Postgres database
const postgres = knex_1.default({
    client: "postgres",
    connection: {
        host: env_1.default.DB_HOST,
        database: env_1.default.DB_NAME,
        user: env_1.default.DB_USER,
        password: env_1.default.DB_PASSWORD
    }
});
(async function () {
    const startTime = Date.now();
    // 3. [NEO4J] Get all users
    const session = neo4j.session();
    session
        .run("MATCH (u:USER) OPTIONAL MATCH (u)-[r:RECEIVED]->(c) WITH u, collect(c.date) as cooldowns RETURN u, cooldowns")
        .subscribe({
        onNext(record) {
            queue.add(async () => {
                // 4. [Postgres] Upsert users
                const user = record.get("u").properties;
                const cooldowns = record.get("cooldowns");
                const email = user.email;
                const password = user.password;
                const verified = !!user.verified;
                const banned = !!user.banned;
                const apikey = user.apikey;
                const created_at = user.createdAt;
                const data = {
                    email,
                    password,
                    verified,
                    banned,
                    ...(apikey && { apikey }),
                    ...(created_at && { created_at }),
                    ...(cooldowns && cooldowns.length && { cooldowns })
                };
                const exists = await postgres("users")
                    .where({
                    email
                })
                    .first();
                if (exists) {
                    await postgres("users")
                        .where("id", exists.id)
                        .update(data);
                }
                else {
                    await postgres("users").insert(data);
                }
            });
        },
        onCompleted() {
            session.close();
            queue.add(() => {
                const endTime = Date.now();
                console.log(`✅ Done! It took ${(endTime - startTime) / 1000} seconds.`);
            });
        },
        onError(error) {
            session.close();
            throw error;
        }
    });
})();
//# sourceMappingURL=02_users.js.map