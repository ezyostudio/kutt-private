"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.query = exports.verify = exports.error = exports.ip = void 0;
const express_validator_1 = require("express-validator");
const Sentry = __importStar(require("@sentry/node"));
const signale_1 = __importDefault(require("signale"));
const utils_1 = require("../utils");
const env_1 = __importDefault(require("../env"));
const ip = (req, res, next) => {
    req.realIP =
        req.headers["x-real-ip"] || req.connection.remoteAddress || "";
    return next();
};
exports.ip = ip;
const error = (error, req, res, next) => {
    if (env_1.default.isDev) {
        signale_1.default.fatal(error);
    }
    if (error instanceof utils_1.CustomError) {
        return res.status(error.statusCode || 500).json({ error: error.message });
    }
    if (env_1.default.SENTRY_PRIVATE_DSN) {
        Sentry.captureException(error);
    }
    return res.status(500).json({ error: "An error occurred." });
};
exports.error = error;
const verify = (req, res, next) => {
    const errors = express_validator_1.validationResult(req);
    if (!errors.isEmpty()) {
        const message = errors.array()[0].msg;
        throw new utils_1.CustomError(message, 400);
    }
    return next();
};
exports.verify = verify;
const query = (req, res, next) => {
    const { limit, skip, all } = req.query;
    const { admin } = req.user || {};
    req.query.limit = parseInt(limit) || 10;
    req.query.skip = parseInt(skip) || 0;
    if (req.query.limit > 50) {
        req.query.limit = 50;
    }
    req.query.all = admin ? all === "true" : false;
    next();
};
exports.query = query;
//# sourceMappingURL=helpers.js.map