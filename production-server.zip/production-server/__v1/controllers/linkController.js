"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ban = exports.reportLink = exports.getLinkStats = exports.deleteUserLink = exports.customDomainRedirection = exports.deleteCustomDomain = exports.setCustomDomain = exports.getUserLinks = exports.goToLink = exports.shortener = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const dns_1 = __importDefault(require("dns"));
const isbot_1 = __importDefault(require("isbot"));
const generate_1 = __importDefault(require("nanoid/generate"));
const universal_analytics_1 = __importDefault(require("universal-analytics"));
const url_1 = __importDefault(require("url"));
const url_regex_1 = __importDefault(require("url-regex"));
const util_1 = require("util");
const domain_1 = require("../db/domain");
const ip_1 = require("../db/ip");
const env_1 = __importDefault(require("../../env"));
const link_1 = require("../db/link");
const mail_1 = __importDefault(require("../../mail/mail"));
const redis = __importStar(require("../../redis"));
const utils_1 = require("../../utils");
const validateBodyController_1 = require("./validateBodyController");
const queues_1 = __importDefault(require("../../queues"));
const dnsLookup = util_1.promisify(dns_1.default.lookup);
const generateId = async () => {
    const address = generate_1.default("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", env_1.default.LINK_LENGTH);
    const link = await link_1.findLink({ address });
    if (!link)
        return address;
    return generateId();
};
const shortener = async (req, res) => {
    try {
        const target = utils_1.addProtocol(req.body.target);
        const targetDomain = utils_1.removeWww(url_1.default.parse(target).hostname);
        const queries = await Promise.all([
            env_1.default.GOOGLE_SAFE_BROWSING_KEY && validateBodyController_1.cooldownCheck(req.user),
            env_1.default.GOOGLE_SAFE_BROWSING_KEY && validateBodyController_1.malwareCheck(req.user, req.body.target),
            req.user && validateBodyController_1.urlCountsCheck(req.user),
            req.user &&
                req.body.reuse &&
                link_1.findLink({
                    target,
                    user_id: req.user.id
                }),
            req.user &&
                req.body.customurl &&
                link_1.findLink({
                    address: req.body.customurl,
                    domain_id: req.user.domain_id || null
                }),
            (!req.user || !req.body.customurl) && generateId(),
            validateBodyController_1.checkBannedDomain(targetDomain),
            validateBodyController_1.checkBannedHost(targetDomain)
        ]);
        // if "reuse" is true, try to return
        // the existent URL without creating one
        if (queries[3]) {
            const { domain_id: d, user_id: u, ...link } = queries[3];
            const shortLink = utils_1.generateShortLink(link.address, req.user.domain);
            const data = {
                ...link,
                id: link.address,
                password: !!link.password,
                reuse: true,
                shortLink,
                shortUrl: shortLink
            };
            return res.json(data);
        }
        // Check if custom link already exists
        if (queries[4]) {
            throw new Error("Custom URL is already in use.");
        }
        // Create new link
        const address = (req.user && req.body.customurl) || queries[5];
        const link = await link_1.createShortLink({
            ...req.body,
            address,
            target
        }, req.user);
        if (!req.user && env_1.default.NON_USER_COOLDOWN) {
            ip_1.addIP(req.realIP);
        }
        return res.json({ ...link, id: link.address });
    }
    catch (error) {
        return res.status(400).json({ error: error.message });
    }
};
exports.shortener = shortener;
const goToLink = async (req, res, next) => {
    const host = utils_1.removeWww(req.headers.host);
    const reqestedId = req.params.id || req.body.id;
    const address = reqestedId.replace("+", "");
    const customDomain = host !== env_1.default.DEFAULT_DOMAIN && host;
    const isBot = isbot_1.default(req.headers["user-agent"]);
    let domain;
    if (customDomain) {
        domain = await domain_1.getDomain({ address: customDomain });
    }
    const link = await link_1.findLink({ address, domain_id: domain && domain.id });
    if (!link) {
        if (host !== env_1.default.DEFAULT_DOMAIN) {
            if (!domain || !domain.homepage)
                return next();
            return res.redirect(302, domain.homepage);
        }
        return next();
    }
    if (link.banned) {
        return res.redirect("/banned");
    }
    const doesRequestInfo = /.*\+$/gi.test(reqestedId);
    if (doesRequestInfo && !link.password) {
        req.linkTarget = link.target;
        req.pageType = "info";
        return next();
    }
    if (link.password && !req.body.password) {
        req.protectedLink = address;
        req.pageType = "password";
        return next();
    }
    if (link.password) {
        const isMatch = await bcryptjs_1.default.compare(req.body.password, link.password);
        if (!isMatch) {
            return res.status(401).json({ error: "Password is not correct" });
        }
        if (link.user_id && !isBot) {
            queues_1.default.visit.add({
                headers: req.headers,
                realIP: req.realIP,
                referrer: req.get("Referrer"),
                link,
                customDomain
            });
        }
        return res.status(200).json({ target: link.target });
    }
    if (link.user_id && !isBot) {
        queues_1.default.visit.add({
            headers: req.headers,
            realIP: req.realIP,
            referrer: req.get("Referrer"),
            link,
            customDomain
        });
    }
    if (env_1.default.GOOGLE_ANALYTICS_UNIVERSAL && !isBot) {
        const visitor = universal_analytics_1.default(env_1.default.GOOGLE_ANALYTICS_UNIVERSAL);
        visitor
            .pageview({
            dp: `/${address}`,
            ua: req.headers["user-agent"],
            uip: req.realIP,
            aip: 1
        })
            .send();
    }
    return res.redirect(link.target);
};
exports.goToLink = goToLink;
const getUserLinks = async (req, res) => {
    const [countAll, list] = await Promise.all([
        link_1.getUserLinksCount({ user_id: req.user.id }),
        link_1.getLinks(req.user.id, req.query)
    ]);
    return res.json({ list, countAll: parseInt(countAll) });
};
exports.getUserLinks = getUserLinks;
const setCustomDomain = async (req, res) => {
    const parsed = url_1.default.parse(req.body.customDomain);
    const customDomain = utils_1.removeWww(parsed.hostname || parsed.href);
    if (!customDomain)
        return res.status(400).json({ error: "Domain is not valid." });
    if (customDomain.length > 40) {
        return res
            .status(400)
            .json({ error: "Maximum custom domain length is 40." });
    }
    if (customDomain === env_1.default.DEFAULT_DOMAIN) {
        return res.status(400).json({ error: "You can't use default domain." });
    }
    const isValidHomepage = !req.body.homepage ||
        url_regex_1.default({ exact: true, strict: false }).test(req.body.homepage);
    if (!isValidHomepage)
        return res.status(400).json({ error: "Homepage is not valid." });
    const homepage = req.body.homepage &&
        (url_1.default.parse(req.body.homepage).protocol
            ? req.body.homepage
            : `http://${req.body.homepage}`);
    const matchedDomain = await domain_1.getDomain({ address: customDomain });
    if (matchedDomain &&
        matchedDomain.user_id &&
        matchedDomain.user_id !== req.user.id) {
        return res.status(400).json({
            error: "Domain is already taken. Contact us for multiple users."
        });
    }
    const userCustomDomain = await domain_1.setDomain({
        address: customDomain,
        homepage
    }, req.user, matchedDomain);
    if (userCustomDomain) {
        return res.status(201).json({
            customDomain: userCustomDomain.address,
            homepage: userCustomDomain.homepage
        });
    }
    return res.status(400).json({ error: "Couldn't set custom domain." });
};
exports.setCustomDomain = setCustomDomain;
const deleteCustomDomain = async (req, res) => {
    const response = await domain_1.deleteDomain(req.user);
    if (response)
        return res.status(200).json({ message: "Domain deleted successfully" });
    return res.status(400).json({ error: "Couldn't delete custom domain." });
};
exports.deleteCustomDomain = deleteCustomDomain;
const customDomainRedirection = async (req, res, next) => {
    const { path } = req;
    const host = utils_1.removeWww(req.headers.host);
    if (host !== env_1.default.DEFAULT_DOMAIN &&
        (path === "/" ||
            validateBodyController_1.preservedUrls
                .filter(l => l !== "url-password")
                .some(item => item === path.replace("/", "")))) {
        const domain = await domain_1.getDomain({ address: host });
        return res.redirect(302, (domain && domain.homepage) || `https://${env_1.default.DEFAULT_DOMAIN + path}`);
    }
    return next();
};
exports.customDomainRedirection = customDomainRedirection;
const deleteUserLink = async (req, res) => {
    const { id, domain } = req.body;
    if (!id) {
        return res.status(400).json({ error: "No id has been provided." });
    }
    const response = await link_1.deleteLink({
        address: id,
        domain: !domain || domain === env_1.default.DEFAULT_DOMAIN ? null : domain,
        user_id: req.user.id
    });
    if (response) {
        return res.status(200).json({ message: "Short link deleted successfully" });
    }
    return res.status(400).json({ error: "Couldn't delete the short link." });
};
exports.deleteUserLink = deleteUserLink;
const getLinkStats = async (req, res) => {
    if (!req.query.id) {
        return res.status(400).json({ error: "No id has been provided." });
    }
    const hostname = utils_1.removeWww(url_1.default.parse(req.query.domain).hostname);
    const hasCustomDomain = req.query.domain && hostname !== env_1.default.DEFAULT_DOMAIN;
    const customDomain = hasCustomDomain
        ? (await domain_1.getDomain({ address: req.query.domain })) || { id: -1 }
        : {};
    const redisKey = req.query.id + (customDomain.address || "") + req.user.email;
    const cached = await redis.get(redisKey);
    if (cached)
        return res.status(200).json(JSON.parse(cached));
    const link = await link_1.findLink({
        address: req.query.id,
        domain_id: hasCustomDomain ? customDomain.id : null,
        user_id: req.user && req.user.id
    });
    if (!link) {
        return res.status(400).json({ error: "Couldn't find the short link." });
    }
    const stats = await link_1.getStats(link, customDomain);
    if (!stats) {
        return res
            .status(400)
            .json({ error: "Could not get the short link stats." });
    }
    const cacheTime = utils_1.getStatsCacheTime(0);
    redis.set(redisKey, JSON.stringify(stats), "EX", cacheTime);
    return res.status(200).json(stats);
};
exports.getLinkStats = getLinkStats;
const reportLink = async (req, res) => {
    if (!req.body.link) {
        return res.status(400).json({ error: "No URL has been provided." });
    }
    const hostname = utils_1.removeWww(url_1.default.parse(req.body.link).hostname);
    if (hostname !== env_1.default.DEFAULT_DOMAIN) {
        return res.status(400).json({
            error: `You can only report a ${env_1.default.DEFAULT_DOMAIN} link`
        });
    }
    const mail = await mail_1.default.sendMail({
        from: env_1.default.MAIL_FROM || env_1.default.MAIL_USER,
        to: env_1.default.REPORT_MAIL,
        subject: "[REPORT]",
        text: req.body.link,
        html: req.body.link
    });
    if (mail.accepted.length) {
        return res
            .status(200)
            .json({ message: "Thanks for the report, we'll take actions shortly." });
    }
    return res
        .status(400)
        .json({ error: "Couldn't submit the report. Try again later." });
};
exports.reportLink = reportLink;
const ban = async (req, res) => {
    if (!req.body.id)
        return res.status(400).json({ error: "No id has been provided." });
    const link = await link_1.findLink({ address: req.body.id, domain_id: null });
    if (!link)
        return res.status(400).json({ error: "Link does not exist." });
    if (link.banned) {
        return res.status(200).json({ message: "Link was banned already." });
    }
    const domain = utils_1.removeWww(url_1.default.parse(link.target).hostname);
    let host;
    if (req.body.host) {
        try {
            const dnsRes = await dnsLookup(domain);
            host = dnsRes && dnsRes.address;
        }
        catch (error) {
            host = null;
        }
    }
    await link_1.banLink({
        adminId: req.user.id,
        domain,
        host,
        address: req.body.id,
        banUser: !!req.body.user
    });
    return res.status(200).json({ message: "Link has been banned successfully" });
};
exports.ban = ban;
//# sourceMappingURL=linkController.js.map