"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkBannedHost = exports.checkBannedDomain = exports.urlCountsCheck = exports.malwareCheck = exports.ipCooldownCheck = exports.cooldownCheck = exports.validateUrl = exports.preservedUrls = exports.validateBody = exports.validationCriterias = void 0;
const date_fns_1 = require("date-fns");
const express_validator_1 = require("express-validator");
const express_validator_2 = require("express-validator");
const util_1 = require("util");
const url_regex_1 = __importDefault(require("url-regex"));
const axios_1 = __importDefault(require("axios"));
const dns_1 = __importDefault(require("dns"));
const url_1 = __importDefault(require("url"));
const utils_1 = require("../../utils");
const user_1 = require("../db/user");
const link_1 = require("../db/link");
const domain_1 = require("../db/domain");
const host_1 = require("../db/host");
const ip_1 = require("../db/ip");
const env_1 = __importDefault(require("../../env"));
const dnsLookup = util_1.promisify(dns_1.default.lookup);
exports.validationCriterias = [
    express_validator_2.body("email")
        .exists()
        .withMessage("Email must be provided.")
        .isEmail()
        .withMessage("Email is not valid.")
        .trim(),
    express_validator_2.body("password", "Password must be at least 8 chars long.")
        .exists()
        .withMessage("Password must be provided.")
        .isLength({ min: 8 })
];
const validateBody = (req, res, next) => {
    const errors = express_validator_1.validationResult(req);
    if (!errors.isEmpty()) {
        const errorsObj = errors.mapped();
        const emailError = errorsObj.email && errorsObj.email.msg;
        const passwordError = errorsObj.password && errorsObj.password.msg;
        return res.status(400).json({ error: emailError || passwordError });
    }
    return next();
};
exports.validateBody = validateBody;
exports.preservedUrls = [
    "login",
    "logout",
    "signup",
    "reset-password",
    "resetpassword",
    "url-password",
    "url-info",
    "settings",
    "stats",
    "verify",
    "api",
    "404",
    "static",
    "images",
    "banned",
    "terms",
    "privacy",
    "protected",
    "report",
    "pricing"
];
const validateUrl = async (req, res, next) => {
    // Validate URL existence
    if (!req.body.target)
        return res.status(400).json({ error: "No target has been provided." });
    // validate URL length
    if (req.body.target.length > 2040) {
        return res.status(400).json({ error: "Maximum URL length is 2040." });
    }
    // Validate URL
    const isValidUrl = url_regex_1.default({ exact: true, strict: false }).test(req.body.target);
    if (!isValidUrl && !/^\w+:\/\//.test(req.body.target))
        return res.status(400).json({ error: "URL is not valid." });
    // If target is the URL shortener itself
    const host = utils_1.removeWww(url_1.default.parse(utils_1.addProtocol(req.body.target)).host);
    if (host === env_1.default.DEFAULT_DOMAIN) {
        return res
            .status(400)
            .json({ error: `${env_1.default.DEFAULT_DOMAIN} URLs are not allowed.` });
    }
    // Validate password length
    if (req.body.password && req.body.password.length > 64) {
        return res.status(400).json({ error: "Maximum password length is 64." });
    }
    // Custom URL validations
    if (req.user && req.body.customurl) {
        // Validate custom URL
        if (!/^[a-zA-Z0-9-_]+$/g.test(req.body.customurl.trim())) {
            return res.status(400).json({ error: "Custom URL is not valid." });
        }
        // Prevent from using preserved URLs
        if (exports.preservedUrls.some(url => url === req.body.customurl)) {
            return res
                .status(400)
                .json({ error: "You can't use this custom URL name." });
        }
        // Validate custom URL length
        if (req.body.customurl.length > 64) {
            return res
                .status(400)
                .json({ error: "Maximum custom URL length is 64." });
        }
    }
    return next();
};
exports.validateUrl = validateUrl;
const cooldownCheck = async (user) => {
    if (user && user.cooldowns) {
        if (user.cooldowns.length > 4) {
            await user_1.banUser(user.id);
            throw new Error("Too much malware requests. You are banned.");
        }
        const hasCooldownNow = user.cooldowns.some(cooldown => date_fns_1.isAfter(date_fns_1.subHours(new Date(), 12), new Date(cooldown)));
        if (hasCooldownNow) {
            throw new Error("Cooldown because of a malware URL. Wait 12h");
        }
    }
};
exports.cooldownCheck = cooldownCheck;
const ipCooldownCheck = async (req, res, next) => {
    const cooldownConfig = env_1.default.NON_USER_COOLDOWN;
    if (req.user || !cooldownConfig)
        return next();
    const ip = await ip_1.getIP(req.realIP);
    if (ip) {
        const timeToWait = cooldownConfig - date_fns_1.differenceInMinutes(new Date(), new Date(ip.created_at));
        return res.status(400).json({
            error: `Non-logged in users are limited. Wait ${timeToWait} ` +
                "minutes or log in."
        });
    }
    next();
};
exports.ipCooldownCheck = ipCooldownCheck;
const malwareCheck = async (user, target) => {
    const isMalware = await axios_1.default.post(`https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${env_1.default.GOOGLE_SAFE_BROWSING_KEY}`, {
        client: {
            clientId: env_1.default.DEFAULT_DOMAIN.toLowerCase().replace(".", ""),
            clientVersion: "1.0.0"
        },
        threatInfo: {
            threatTypes: [
                "THREAT_TYPE_UNSPECIFIED",
                "MALWARE",
                "SOCIAL_ENGINEERING",
                "UNWANTED_SOFTWARE",
                "POTENTIALLY_HARMFUL_APPLICATION"
            ],
            platformTypes: ["ANY_PLATFORM", "PLATFORM_TYPE_UNSPECIFIED"],
            threatEntryTypes: [
                "EXECUTABLE",
                "URL",
                "THREAT_ENTRY_TYPE_UNSPECIFIED"
            ],
            threatEntries: [{ url: target }]
        }
    });
    if (isMalware.data && isMalware.data.matches) {
        if (user) {
            await user_1.addCooldown(user.id);
        }
        throw new utils_1.CustomError(user ? "Malware detected! Cooldown for 12h." : "Malware detected!");
    }
};
exports.malwareCheck = malwareCheck;
const urlCountsCheck = async (user) => {
    const count = await link_1.getUserLinksCount({
        user_id: user.id,
        date: date_fns_1.subDays(new Date(), 1)
    });
    if (count > env_1.default.USER_LIMIT_PER_DAY) {
        throw new utils_1.CustomError(`You have reached your daily limit (${env_1.default.USER_LIMIT_PER_DAY}). Please wait 24h.`);
    }
};
exports.urlCountsCheck = urlCountsCheck;
const checkBannedDomain = async (domain) => {
    const bannedDomain = await domain_1.getDomain({ address: domain, banned: true });
    if (bannedDomain) {
        throw new utils_1.CustomError("URL is containing malware/scam.");
    }
};
exports.checkBannedDomain = checkBannedDomain;
const checkBannedHost = async (domain) => {
    let isHostBanned;
    try {
        const dnsRes = await dnsLookup(domain);
        isHostBanned = await host_1.getHost({
            address: dnsRes && dnsRes.address,
            banned: true
        });
    }
    catch (error) {
        isHostBanned = null;
    }
    if (isHostBanned) {
        throw new utils_1.CustomError("URL is containing malware/scam.");
    }
};
exports.checkBannedHost = checkBannedHost;
//# sourceMappingURL=validateBodyController.js.map