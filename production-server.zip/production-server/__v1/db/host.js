"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.banHost = exports.getHost = void 0;
const knex_1 = __importDefault(require("../../knex"));
const redis = __importStar(require("../../redis"));
const utils_1 = require("../../utils");
const getHost = async (data) => {
    const getData = {
        ...data,
        ...(data.address && { address: data.address.toLowerCase() })
    };
    const redisKey = utils_1.getRedisKey.host(getData.address);
    const cachedHost = await redis.get(redisKey);
    if (cachedHost)
        return JSON.parse(cachedHost);
    const host = await knex_1.default("hosts")
        .where(getData)
        .first();
    if (host) {
        redis.set(redisKey, JSON.stringify(host), "EX", 60 * 60 * 6);
    }
    return host;
};
exports.getHost = getHost;
const banHost = async (addressToBan, banned_by_id) => {
    const address = addressToBan.toLowerCase();
    const currentHost = await knex_1.default("hosts")
        .where({ address })
        .first();
    if (currentHost) {
        await knex_1.default("hosts")
            .where({ address })
            .update({
            banned: true,
            banned_by_id,
            updated_at: new Date().toISOString()
        });
    }
    else {
        await knex_1.default("hosts").insert({ address, banned: true, banned_by_id });
    }
    if (currentHost) {
        redis.del(utils_1.getRedisKey.host(currentHost.address));
    }
    return currentHost;
};
exports.banHost = banHost;
//# sourceMappingURL=host.js.map