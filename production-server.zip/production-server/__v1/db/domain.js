"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.banDomain = exports.deleteDomain = exports.setDomain = exports.getDomain = void 0;
const knex_1 = __importDefault(require("../../knex"));
const redis = __importStar(require("../../redis"));
const utils_1 = require("../../utils");
const getDomain = async (data) => {
    const getData = {
        ...data,
        ...(data.address && { address: data.address.toLowerCase() }),
        ...(data.homepage && { homepage: data.homepage.toLowerCase() })
    };
    const redisKey = utils_1.getRedisKey.domain(getData.address);
    const cachedDomain = await redis.get(redisKey);
    if (cachedDomain)
        return JSON.parse(cachedDomain);
    const domain = await knex_1.default("domains")
        .where(getData)
        .first();
    if (domain) {
        redis.set(redisKey, JSON.stringify(domain), "EX", 60 * 60 * 6);
    }
    return domain;
};
exports.getDomain = getDomain;
const setDomain = async (data, user, matchedDomain) => {
    // 1. If user has domain, remove it from their possession
    await knex_1.default("domains")
        .where({ user_id: user.id })
        .update({ user_id: null });
    // 2. Create or update the domain with user's ID
    let domain;
    const updateDate = {
        address: data.address.toLowerCase(),
        homepage: data.homepage && data.homepage.toLowerCase(),
        user_id: user.id,
        updated_at: new Date().toISOString()
    };
    if (matchedDomain) {
        const [response] = await knex_1.default("domains")
            .where("id", matchedDomain.id)
            .update(updateDate, "*");
        domain = response;
    }
    else {
        const [response] = await knex_1.default("domains").insert(updateDate, "*");
        domain = response;
    }
    redis.del(utils_1.getRedisKey.user(user.email));
    redis.del(utils_1.getRedisKey.user(user.apikey));
    redis.del(utils_1.getRedisKey.domain(updateDate.address));
    return domain;
};
exports.setDomain = setDomain;
const deleteDomain = async (user) => {
    // Remove user from domain, do not actually delete the domain
    const [domain] = await knex_1.default("domains")
        .where({ user_id: user.id })
        .update({ user_id: null, updated_at: new Date().toISOString() }, "*");
    if (domain) {
        redis.del(utils_1.getRedisKey.domain(domain.address));
    }
    redis.del(utils_1.getRedisKey.user(user.email));
    redis.del(utils_1.getRedisKey.user(user.apikey));
    return domain;
};
exports.deleteDomain = deleteDomain;
const banDomain = async (addressToban, banned_by_id) => {
    const address = addressToban.toLowerCase();
    const currentDomain = await exports.getDomain({ address });
    let domain;
    if (currentDomain) {
        const updates = await knex_1.default("domains")
            .where({ address })
            .update({ banned: true, banned_by_id, updated_at: new Date().toISOString() }, "*");
        domain = updates[0];
    }
    else {
        const inserts = await knex_1.default("domains").insert({ address, banned: true, banned_by_id }, "*");
        domain = inserts[0];
    }
    if (domain) {
        redis.del(utils_1.getRedisKey.domain(domain.address));
    }
    return domain;
};
exports.banDomain = banDomain;
//# sourceMappingURL=domain.js.map