"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.banUser = exports.addCooldown = exports.resetPassword = exports.requestPasswordReset = exports.generateApiKey = exports.changePassword = exports.verifyUser = exports.createUser = exports.getUser = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const nanoid_1 = __importDefault(require("nanoid"));
const v4_1 = __importDefault(require("uuid/v4"));
const date_fns_1 = require("date-fns");
const knex_1 = __importDefault(require("../../knex"));
const redis = __importStar(require("../../redis"));
const utils_1 = require("../../utils");
const getUser = async (emailOrKey = "") => {
    const redisKey = utils_1.getRedisKey.user(emailOrKey);
    const cachedUser = await redis.get(redisKey);
    if (cachedUser)
        return JSON.parse(cachedUser);
    const user = await knex_1.default("users")
        .select("users.id", "users.apikey", "users.banned", "users.banned_by_id", "users.cooldowns", "users.created_at", "users.email", "users.password", "users.updated_at", "users.verified", "domains.id as domain_id", "domains.homepage as homepage", "domains.address as domain")
        .where("email", "ILIKE", emailOrKey)
        .orWhere({ apikey: emailOrKey })
        .leftJoin("domains", "users.id", "domains.user_id")
        .first();
    if (user) {
        redis.set(redisKey, JSON.stringify(user), "EX", 60 * 60 * 1);
    }
    return user;
};
exports.getUser = getUser;
const createUser = async (emailToCreate, password, user) => {
    const email = emailToCreate.toLowerCase();
    const salt = await bcryptjs_1.default.genSalt(12);
    const hashedPassword = await bcryptjs_1.default.hash(password, salt);
    const data = {
        email,
        password: hashedPassword,
        verification_token: v4_1.default(),
        verification_expires: date_fns_1.addMinutes(new Date(), 60).toISOString()
    };
    if (user) {
        await knex_1.default("users")
            .where({ email })
            .update({ ...data, updated_at: new Date().toISOString() });
    }
    else {
        await knex_1.default("users").insert(data);
    }
    redis.del(utils_1.getRedisKey.user(email));
    return {
        ...user,
        ...data
    };
};
exports.createUser = createUser;
const verifyUser = async (verification_token) => {
    const [user] = await knex_1.default("users")
        .where({ verification_token })
        .andWhere("verification_expires", ">", new Date().toISOString())
        .update({
        verified: true,
        verification_token: undefined,
        verification_expires: undefined,
        updated_at: new Date().toISOString()
    }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
    }
    return user;
};
exports.verifyUser = verifyUser;
const changePassword = async (id, newPassword) => {
    const salt = await bcryptjs_1.default.genSalt(12);
    const password = await bcryptjs_1.default.hash(newPassword, salt);
    const [user] = await knex_1.default("users")
        .where({ id })
        .update({ password, updated_at: new Date().toISOString() }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
        redis.del(utils_1.getRedisKey.user(user.apikey));
    }
    return user;
};
exports.changePassword = changePassword;
const generateApiKey = async (id) => {
    const apikey = nanoid_1.default(40);
    const [user] = await knex_1.default("users")
        .where({ id })
        .update({ apikey, updated_at: new Date().toISOString() }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
        redis.del(utils_1.getRedisKey.user(user.apikey));
    }
    return user && apikey;
};
exports.generateApiKey = generateApiKey;
const requestPasswordReset = async (emailToMatch) => {
    const email = emailToMatch.toLowerCase();
    const reset_password_token = v4_1.default();
    const [user] = await knex_1.default("users")
        .where({ email })
        .update({
        reset_password_token,
        reset_password_expires: date_fns_1.addMinutes(new Date(), 30).toISOString(),
        updated_at: new Date().toISOString()
    }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
        redis.del(utils_1.getRedisKey.user(user.apikey));
    }
    return user;
};
exports.requestPasswordReset = requestPasswordReset;
const resetPassword = async (reset_password_token) => {
    const [user] = await knex_1.default("users")
        .where({ reset_password_token })
        .andWhere("reset_password_expires", ">", new Date().toISOString())
        .update({
        reset_password_expires: null,
        reset_password_token: null,
        updated_at: new Date().toISOString()
    }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
        redis.del(utils_1.getRedisKey.user(user.apikey));
    }
    return user;
};
exports.resetPassword = resetPassword;
const addCooldown = async (id) => {
    const [user] = await knex_1.default("users")
        .where({ id })
        .update({
        cooldowns: knex_1.default.raw("array_append(cooldowns, ?)", [
            new Date().toISOString()
        ]),
        updated_at: new Date().toISOString()
    }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
        redis.del(utils_1.getRedisKey.user(user.apikey));
    }
    return user;
};
exports.addCooldown = addCooldown;
const banUser = async (id, banned_by_id) => {
    const [user] = await knex_1.default("users")
        .where({ id })
        .update({ banned: true, banned_by_id, updated_at: new Date().toISOString() }, "*");
    if (user) {
        redis.del(utils_1.getRedisKey.user(user.email));
        redis.del(utils_1.getRedisKey.user(user.apikey));
    }
    return user;
};
exports.banUser = banUser;
//# sourceMappingURL=user.js.map