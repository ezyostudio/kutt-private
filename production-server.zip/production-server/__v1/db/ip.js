"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clearIPs = exports.getIP = exports.addIP = void 0;
const date_fns_1 = require("date-fns");
const knex_1 = __importDefault(require("../../knex"));
const env_1 = __importDefault(require("../../env"));
const addIP = async (ipToGet) => {
    const ip = ipToGet.toLowerCase();
    const currentIP = await knex_1.default("ips")
        .where({ ip })
        .first();
    if (currentIP) {
        const currentDate = new Date().toISOString();
        await knex_1.default("ips")
            .where({ ip })
            .update({
            created_at: currentDate,
            updated_at: currentDate
        });
    }
    else {
        await knex_1.default("ips").insert({ ip });
    }
    return ip;
};
exports.addIP = addIP;
const getIP = async (ip) => {
    const cooldownConfig = env_1.default.NON_USER_COOLDOWN;
    const matchedIp = await knex_1.default("ips")
        .where({ ip: ip.toLowerCase() })
        .andWhere("created_at", ">", date_fns_1.subMinutes(new Date(), cooldownConfig).toISOString())
        .first();
    return matchedIp;
};
exports.getIP = getIP;
const clearIPs = async () => knex_1.default("ips")
    .where("created_at", "<", date_fns_1.subMinutes(new Date(), env_1.default.NON_USER_COOLDOWN).toISOString())
    .delete();
exports.clearIPs = clearIPs;
//# sourceMappingURL=ip.js.map