"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.banLink = exports.getStats = exports.deleteLink = exports.getLinks = exports.getUserLinksCount = exports.findLink = exports.createVisit = exports.addLinkCount = exports.createShortLink = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const date_fns_1 = require("date-fns");
const knex_1 = __importDefault(require("../../knex"));
const redis = __importStar(require("../../redis"));
const utils_1 = require("../../utils");
const domain_1 = require("./domain");
const host_1 = require("./host");
const user_1 = require("./user");
const createShortLink = async (data, user) => {
    const { id: user_id = null, domain, domain_id = null } = user || {};
    let password;
    if (data.password) {
        const salt = await bcryptjs_1.default.genSalt(12);
        password = await bcryptjs_1.default.hash(data.password, salt);
    }
    const [link] = await knex_1.default("links").insert({
        domain_id,
        address: data.address,
        password,
        target: data.target,
        user_id
    }, "*");
    return {
        ...link,
        password: !!data.password,
        reuse: !!data.reuse,
        shortLink: utils_1.generateShortLink(data.address, domain),
        shortUrl: utils_1.generateShortLink(data.address, domain)
    };
};
exports.createShortLink = createShortLink;
const addLinkCount = async (id) => {
    return knex_1.default("links")
        .where({ id })
        .increment("visit_count", 1);
};
exports.addLinkCount = addLinkCount;
const createVisit = async (params) => {
    const data = {
        ...params,
        country: params.country.toLowerCase(),
        referrer: params.referrer.toLowerCase()
    };
    const visit = await knex_1.default("visits")
        .where({ link_id: params.id })
        .andWhere(knex_1.default.raw("date_trunc('hour', created_at) = date_trunc('hour', ?)", [
        knex_1.default.fn.now()
    ]))
        .first();
    if (visit) {
        await knex_1.default("visits")
            .where({ id: visit.id })
            .increment(`br_${data.browser}`, 1)
            .increment(`os_${data.os}`, 1)
            .increment("total", 1)
            .update({
            updated_at: new Date().toISOString(),
            countries: knex_1.default.raw("jsonb_set(countries, '{??}', (COALESCE(countries->>?,'0')::int + 1)::text::jsonb)", [data.country, data.country]),
            referrers: knex_1.default.raw("jsonb_set(referrers, '{??}', (COALESCE(referrers->>?,'0')::int + 1)::text::jsonb)", [data.referrer, data.referrer])
        });
    }
    else {
        await knex_1.default("visits").insert({
            [`br_${data.browser}`]: 1,
            countries: { [data.country]: 1 },
            referrers: { [data.referrer]: 1 },
            [`os_${data.os}`]: 1,
            total: 1,
            link_id: data.id
        });
    }
    return visit;
};
exports.createVisit = createVisit;
const findLink = async ({ address, domain_id, user_id, target }) => {
    const redisKey = utils_1.getRedisKey.link(address, domain_id, user_id);
    const cachedLink = await redis.get(redisKey);
    if (cachedLink)
        return JSON.parse(cachedLink);
    const link = await knex_1.default("links")
        .where({
        ...(address && { address }),
        ...(domain_id && { domain_id }),
        ...(user_id && { user_id }),
        ...(target && { target })
    })
        .first();
    if (link) {
        redis.set(redisKey, JSON.stringify(link), "EX", 60 * 60 * 2);
    }
    return link;
};
exports.findLink = findLink;
const getUserLinksCount = async (params) => {
    const model = knex_1.default("links").where({ user_id: params.user_id });
    // TODO: Test counts;
    let res;
    if (params.date) {
        res = await model
            .andWhere("created_at", ">", params.date.toISOString())
            .count("id");
    }
    else {
        res = await model.count("id");
    }
    return res[0] && res[0].count;
};
exports.getUserLinksCount = getUserLinksCount;
const getLinks = async (user_id, options = {}) => {
    const { count = "5", page = "1", search = "" } = options;
    const limit = parseInt(count) < 50 ? parseInt(count) : 50;
    const offset = (parseInt(page) - 1) * limit;
    const model = knex_1.default("links")
        .select("links.id", "links.address", "links.banned", "links.created_at", "links.domain_id", "links.updated_at", "links.password", "links.target", "links.visit_count", "links.user_id", "links.uuid", "domains.address as domain")
        .offset(offset)
        .limit(limit)
        .orderBy("created_at", "desc")
        .where("links.user_id", user_id);
    if (search) {
        model.andWhereRaw("links.address || ' ' || target ILIKE '%' || ? || '%'", [
            search
        ]);
    }
    const matchedLinks = await model.leftJoin("domains", "links.domain_id", "domains.id");
    const links = matchedLinks.map(link => ({
        ...link,
        id: link.address,
        password: !!link.password,
        shortLink: utils_1.generateShortLink(link.address, link.domain),
        shortUrl: utils_1.generateShortLink(link.address, link.domain)
    }));
    return links;
};
exports.getLinks = getLinks;
const deleteLink = async (data) => {
    const link = await knex_1.default("links")
        .select("links.id", "domains.address as domain")
        .where("links.address", data.address)
        .where("links.user_id", data.user_id)
        .where({
        ...(!data.domain && { domain_id: null })
    })
        .leftJoin("domains", "links.domain_id", "domains.id")
        .first();
    if (!link)
        return;
    if (link.domain !== data.domain) {
        return;
    }
    await knex_1.default("visits")
        .where("link_id", link.id)
        .delete();
    const deletedLink = await knex_1.default("links")
        .where("id", link.id)
        .delete();
    redis.del(utils_1.getRedisKey.link(link.address, link.domain_id, link.user_id));
    return !!deletedLink;
};
exports.deleteLink = deleteLink;
const getInitStats = () => Object.create({
    browser: {
        chrome: 0,
        edge: 0,
        firefox: 0,
        ie: 0,
        opera: 0,
        other: 0,
        safari: 0
    },
    os: {
        android: 0,
        ios: 0,
        linux: 0,
        macos: 0,
        other: 0,
        windows: 0
    },
    country: {},
    referrer: {}
});
const STATS_PERIODS = [
    [1, "lastDay"],
    [7, "lastWeek"],
    [30, "lastMonth"]
];
const getStats = async (link, domain) => {
    const stats = {
        lastDay: {
            stats: getInitStats(),
            views: new Array(24).fill(0)
        },
        lastWeek: {
            stats: getInitStats(),
            views: new Array(7).fill(0)
        },
        lastMonth: {
            stats: getInitStats(),
            views: new Array(30).fill(0)
        },
        allTime: {
            stats: getInitStats(),
            views: new Array(18).fill(0)
        }
    };
    const visitsStream = knex_1.default("visits")
        .where("link_id", link.id)
        .stream();
    const nowUTC = utils_1.getUTCDate();
    const now = new Date();
    for await (const visit of visitsStream) {
        STATS_PERIODS.forEach(([days, type]) => {
            const isIncluded = date_fns_1.isAfter(new Date(visit.created_at), date_fns_1.subDays(nowUTC, days));
            if (isIncluded) {
                const diffFunction = utils_1.getDifferenceFunction(type);
                const diff = diffFunction(now, visit.created_at);
                const index = stats[type].views.length - diff - 1;
                const view = stats[type].views[index];
                const period = stats[type].stats;
                stats[type].stats = {
                    browser: {
                        chrome: period.browser.chrome + visit.br_chrome,
                        edge: period.browser.edge + visit.br_edge,
                        firefox: period.browser.firefox + visit.br_firefox,
                        ie: period.browser.ie + visit.br_ie,
                        opera: period.browser.opera + visit.br_opera,
                        other: period.browser.other + visit.br_other,
                        safari: period.browser.safari + visit.br_safari
                    },
                    os: {
                        android: period.os.android + visit.os_android,
                        ios: period.os.ios + visit.os_ios,
                        linux: period.os.linux + visit.os_linux,
                        macos: period.os.macos + visit.os_macos,
                        other: period.os.other + visit.os_other,
                        windows: period.os.windows + visit.os_windows
                    },
                    country: {
                        ...period.country,
                        ...Object.entries(visit.countries).reduce((obj, [country, count]) => ({
                            ...obj,
                            [country]: (period.country[country] || 0) + count
                        }), {})
                    },
                    referrer: {
                        ...period.referrer,
                        ...Object.entries(visit.referrers).reduce((obj, [referrer, count]) => ({
                            ...obj,
                            [referrer]: (period.referrer[referrer] || 0) + count
                        }), {})
                    }
                };
                stats[type].views[index] = view + visit.total;
            }
        });
        const allTime = stats.allTime.stats;
        const diffFunction = utils_1.getDifferenceFunction("allTime");
        const diff = diffFunction(date_fns_1.set(new Date(), { date: 1 }), date_fns_1.set(new Date(visit.created_at), { date: 1 }));
        const index = stats.allTime.views.length - diff - 1;
        const view = stats.allTime.views[index];
        stats.allTime.stats = {
            browser: {
                chrome: allTime.browser.chrome + visit.br_chrome,
                edge: allTime.browser.edge + visit.br_edge,
                firefox: allTime.browser.firefox + visit.br_firefox,
                ie: allTime.browser.ie + visit.br_ie,
                opera: allTime.browser.opera + visit.br_opera,
                other: allTime.browser.other + visit.br_other,
                safari: allTime.browser.safari + visit.br_safari
            },
            os: {
                android: allTime.os.android + visit.os_android,
                ios: allTime.os.ios + visit.os_ios,
                linux: allTime.os.linux + visit.os_linux,
                macos: allTime.os.macos + visit.os_macos,
                other: allTime.os.other + visit.os_other,
                windows: allTime.os.windows + visit.os_windows
            },
            country: {
                ...allTime.country,
                ...Object.entries(visit.countries).reduce((obj, [country, count]) => ({
                    ...obj,
                    [country]: (allTime.country[country] || 0) + count
                }), {})
            },
            referrer: {
                ...allTime.referrer,
                ...Object.entries(visit.referrers).reduce((obj, [referrer, count]) => ({
                    ...obj,
                    [referrer]: (allTime.referrer[referrer] || 0) + count
                }), {})
            }
        };
        stats.allTime.views[index] = view + visit.total;
    }
    const response = {
        allTime: {
            stats: utils_1.statsObjectToArray(stats.allTime.stats),
            views: stats.allTime.views
        },
        id: link.address,
        lastDay: {
            stats: utils_1.statsObjectToArray(stats.lastDay.stats),
            views: stats.lastDay.views
        },
        lastMonth: {
            stats: utils_1.statsObjectToArray(stats.lastMonth.stats),
            views: stats.lastMonth.views
        },
        lastWeek: {
            stats: utils_1.statsObjectToArray(stats.lastWeek.stats),
            views: stats.lastWeek.views
        },
        shortLink: utils_1.generateShortLink(link.address, domain.address),
        shortUrl: utils_1.generateShortLink(link.address, domain.address),
        target: link.target,
        total: link.visit_count,
        updatedAt: new Date().toISOString()
    };
    return response;
};
exports.getStats = getStats;
const banLink = async (data) => {
    const tasks = [];
    const banned_by_id = data.adminId;
    // Ban link
    const [link] = await knex_1.default("links")
        .where({ address: data.address, domain_id: null })
        .update({ banned: true, banned_by_id, updated_at: new Date().toISOString() }, "*");
    if (!link)
        throw new Error("No link has been found.");
    // If user, ban user and all of their links.
    if (data.banUser && link.user_id) {
        tasks.push(user_1.banUser(link.user_id, banned_by_id));
        tasks.push(knex_1.default("links")
            .where({ user_id: link.user_id })
            .update({ banned: true, banned_by_id, updated_at: new Date().toISOString() }, "*"));
    }
    // Ban host
    if (data.host)
        tasks.push(host_1.banHost(data.host, banned_by_id));
    // Ban domain
    if (data.domain)
        tasks.push(domain_1.banDomain(data.domain, banned_by_id));
    redis.del(utils_1.getRedisKey.link(link.address, link.domain_id, link.user_id));
    redis.del(utils_1.getRedisKey.link(link.address, link.domain_id));
    redis.del(utils_1.getRedisKey.link(link.address));
    return Promise.all(tasks);
};
exports.banLink = banLink;
//# sourceMappingURL=link.js.map