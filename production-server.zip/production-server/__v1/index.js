"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_async_handler_1 = __importDefault(require("express-async-handler"));
const express_1 = require("express");
const cors_1 = __importDefault(require("cors"));
const validateBodyController_1 = require("./controllers/validateBodyController");
const auth = __importStar(require("../handlers/auth"));
const link = __importStar(require("./controllers/linkController"));
const router = express_1.Router();
/* URL shortener */
router.post("/url/submit", cors_1.default(), express_async_handler_1.default(auth.apikey), express_async_handler_1.default(auth.jwt), express_async_handler_1.default(auth.recaptcha), express_async_handler_1.default(validateBodyController_1.validateUrl), express_async_handler_1.default(validateBodyController_1.ipCooldownCheck), express_async_handler_1.default(link.shortener));
router.post("/url/deleteurl", express_async_handler_1.default(auth.apikey), express_async_handler_1.default(auth.jwt), express_async_handler_1.default(link.deleteUserLink));
router.get("/url/geturls", express_async_handler_1.default(auth.apikey), express_async_handler_1.default(auth.jwt), express_async_handler_1.default(link.getUserLinks));
router.post("/url/customdomain", express_async_handler_1.default(auth.jwt), express_async_handler_1.default(link.setCustomDomain));
router.delete("/url/customdomain", express_async_handler_1.default(auth.jwt), express_async_handler_1.default(link.deleteCustomDomain));
router.get("/url/stats", express_async_handler_1.default(auth.apikey), express_async_handler_1.default(auth.jwt), express_async_handler_1.default(link.getLinkStats));
router.post("/url/requesturl", express_async_handler_1.default(link.goToLink));
router.post("/url/report", express_async_handler_1.default(link.reportLink));
router.post("/url/admin/ban", express_async_handler_1.default(auth.apikey), express_async_handler_1.default(auth.jwt), express_async_handler_1.default(auth.admin), express_async_handler_1.default(link.ban));
exports.default = router;
//# sourceMappingURL=index.js.map