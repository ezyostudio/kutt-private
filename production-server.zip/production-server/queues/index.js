"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const queues_1 = require("./queues");
exports.default = {
    visit: queues_1.visit
};
//# sourceMappingURL=index.js.map